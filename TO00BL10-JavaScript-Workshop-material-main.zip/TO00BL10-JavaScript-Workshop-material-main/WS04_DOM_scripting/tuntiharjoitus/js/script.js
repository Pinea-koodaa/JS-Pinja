let d = new Date();
alert("Today's date is " + d);

let d2 = new Date();
document.body.innerHTML = "<h1>Today's date is " + d2 + "</h1>"