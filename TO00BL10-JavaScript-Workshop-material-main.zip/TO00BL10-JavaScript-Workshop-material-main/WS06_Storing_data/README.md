# Workshop 6: Using Localstorage

* * *

## Exercise 1: Saving the entered data

Use localstorage to save the data entered to the form fields below. The JavaScript code should read the values entered when the user clicks the button and save the data into localstorage. Use Developer Tools to study what data is saved and how. You can even try to modify this data using the developer tools.

**Note: Some versions of Chrome's Web Developer Tools have a known issue with showing LocalStorage so if nothing is showing up, try with a different browser.**

<div><label for="destination">Destination:</label> <input type="text" name="textfield" id="destination"></div>

<div><label for="arrival">Arrival Date:</label> <input type="text" name="textfield" id="arrival"></div>

<div id="services" class="border">

Services:

<div><label><input type="checkbox" name="CheckboxGroup1" value="Internet" id="CheckboxGroup1_0">Internet</label></div>

<div><label><input type="checkbox" name="CheckboxGroup1" value="AC" id="CheckboxGroup1_1">Air Conditioning</label></div>

<div><label><input type="checkbox" name="CheckboxGroup1" value="minibar" id="CheckboxGroup1_2">Minibar</label></div>

<div><label><input type="checkbox" name="CheckboxGroup1" value="car" id="CheckboxGroup1_3">Car rent</label></div>

<div><label><input type="checkbox" name="CheckboxGroup1" value="sauna" id="CheckboxGroup1_4">Sauna</label></div>

</div>

<div class="clear">

<input type="button" name="button" id="button" value="Reserve" onclick="getData()">

</div>

* * *

<div>

## Exercise 2: Reloading the saved data

After you have managed to save some data to a localstorage, its time to utilize it. Add a piece of code to this page, which will check if there is saved data available from the first assignment, and load them into a div with an id="sessionData". This should happen when the page is loaded, because we want the data to be loaded then as well. HINT: use onLoad - event on the body tag.

<div id="sessiondata">Session data goes here!</div>

</div>

* * *

<div>

## Exercise 3: Sessionstorage vs. localstorage

Compare sessionstorage and localstorage. Think of a few examples on where each should be used. Copy the form above here and implement sessionstorage for it. See what happens, when you close the browser. You can utilize developer tools to study the data (F12, select Application tab, then LocalStorage on the left).

</div>

* * *

<div>

## Exercise 4:

Try to add localstorage features to your project work. This means, that todo-list for example, would remember the data that you have entered between browser refresh and even restarts.

</div>