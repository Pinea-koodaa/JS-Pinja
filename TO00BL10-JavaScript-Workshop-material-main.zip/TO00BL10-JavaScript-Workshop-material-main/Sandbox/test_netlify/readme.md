# LocalStorage Playground
A practice repo for students learning to work with localStorage and JSON

## Instructions
When a user clicks the “Add Contact” button, their name and email should be stored as an object in localStorage
When a user clicks the “Display Contact” button, their name and email should be pulled from localStorage, and displayed in the .display-area section (NOTE: The HTML structure for this is up to you!)
BONUS: How could you add and display multiple users instead of just one?